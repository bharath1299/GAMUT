package main

import (
	"fmt"
	"strings"
)

func main() {
	var companyName = "GoConference"
	const numberOfTickets = 50
	var remainingTickets uint = 50
	var firstName string
	var lastName string
	var userTickets uint
	var email string
	var bookings []string
	for remainingTickets > 0 {
		fmt.Printf("WELCOME TO %v\n", companyName)
		fmt.Println("ENTER YOUR FIRST NAME = ")
		fmt.Scan(&firstName)
		fmt.Println("ENTER YOUR LAST NAME = ")
		fmt.Scan(&lastName)
		fmt.Println("ENTER YOUR EMAIL = ")
		fmt.Scan(&email)
		fmt.Println("ENTER NUMBER OF TICKETS = ")
		fmt.Scan(&userTickets)
		if userTickets <= remainingTickets {
			fmt.Printf("Thank you %v %v for booking %v tickets. You'll get a confirmation mail at %v soon.\n", firstName, lastName, userTickets, email)
			bookings = append(bookings, firstName+" "+lastName)
			remainingTickets = remainingTickets - userTickets
			fmt.Printf("REMAINING TICKETS = %v\n", remainingTickets)
			var firstNames []string
			for _, booking := range bookings {
				var names = strings.Fields(booking)
				fmt.Printf("%v", names)
				firstNames = append(firstNames, names[0])
				fmt.Printf("First Name of booked people = %v\n", firstNames)
			}
		} else {
			fmt.Printf("You cannot book %v tickets as we only have %v tickets remaining\n", userTickets, remainingTickets)
		}
	}

}
